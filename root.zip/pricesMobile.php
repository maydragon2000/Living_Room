 <span class="white"><b>$4.5k</b></span> 
                <span style="color: #FFCCFF">a month flat</span>
                <span class="star">
              <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path fill="#f90" d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2L9.19 8.63L2 9.24l5.46 4.73L5.82 21z"/></svg>
                </span> 
                <a href="https://www.google.com/maps/dir//Pebble+Brook+Senior+Assisted+Living,+33722+Pebble+Brook+Cir,+Temecula,+CA+92592/@33.4868017,-117.1061711,13z/data=!3m1!4b1!4m9!4m8!1m0!1m5!1m1!1s0x80db78a9c85a16cf:0xab889f9d2ade632!2m2!1d-117.0711517!2d33.4868066!3e0" target="_blank" style="text-decoration:none">
                    <span><b>5</b></span>
                    <span style="color: #FFCCFF">/ 5 star review</span>
                </a>