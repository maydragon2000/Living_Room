    <li><a style="text-decoration:none;color:#fff;" href="https://pebblebrookseniorhomecare.com/">Home</a></li>
    <li><a style="text-decoration:none;color:#fff;" href="https://pebblebrookseniorhomecare.com/gallery/">Gallery</a></li>
    <li><a style="text-decoration:none;color:#fff;" href="https://pebblebrookseniorhomecare.com/events/">Events</a></li>
                <li><a style="text-decoration:none;color:#fff;" href="https://pebblebrookseniorhomecare.com/basics/">Services</a></li>
                <li><a style="text-decoration:none;color:#fff;" href="https://pebblebrookseniorhomecare.com/contact/">Contact</a></li>
                <li><a style="text-decoration:none;color:#fff;" href="https://pebblebrookseniorhomecare.com/sitemap.xml">Sitemap</a></li>
                <script>
    if($(window).width()>1200){
        $('.menu.main-ul').css('display',"block")
    }
    $(window).on('resize', function(){
        var win = $(this); //this = window
        if (win.width() < 1200) {
            $('.menu.main-ul').css('display',"none")
        } else {
            $('.menu.main-ul').css('display',"block")
        }
    });    
</script><!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-FJDR8H6SY4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-FJDR8H6SY4');
</script>