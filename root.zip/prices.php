 <div class=" flex-item">

                    <div class="white" style="font-size: 34px;font-weight: bold;margin-right: 5px">
                        <span>1</span>
                    </div>
                    <div class="white">
                        <span style="color: #FFF;font-size: 18px">Private room</span> <br>
                        <span style="color: #e2b8e2;font-size: 14px;">Now open</span>
                    </div>
                </div>
                <div class="header-divider"></div>
                 
    <div class="flex-item">
                   <div class="flex-item-box">
                    
                    <span class="star middle">
                        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="0.8rem" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path fill="#f90" d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2L9.19 8.63L2 9.24l5.46 4.73L5.82 21z"/></svg>
                    </span> 
                    <a href="https://www.google.com/search?q=Pebble+Brook+Senior+home+care&oq=peb&aqs=chrome.1.69i60j69i59l2j69i57j69i60l4.2036j0j7&sourceid=chrome&ie=UTF-8#lrd=0x80db78a9c85a16cf:0xab889f9d2ade632,1,,," style="text-decoration:none" rel="nofollow"></a>
                        <span style="color: #FFF;font-size: 18px">Rated 5 / 5 stars</span>
                     <br>
        
                    <a href="https://www.google.com/search?q=Pebble+Brook+Senior+home+care&oq=peb&aqs=chrome.1.69i60j69i59l2j69i57j69i60l4.2036j0j7&sourceid=chrome&ie=UTF-8#lrd=0x80db78a9c85a16cf:0xab889f9d2ade632,1,,," style="color: #e2b8e2;font-size: 14px; margin-left:17px;" rel="nofollow"> Read Our Reviews</a>
                    
                </div>
                </div>

                <div class="header-divider"></div>
                <div class="flex-item">
                   <div class="flex-item-box">
                   <span style="color: #FFF;font-size: 18px">$</span>
                   <span style="color: #FFF;font-size: 18px">4,500 Monthly</span><br>
                    
                    <span style="color: #fff;font-size: 14px; margin-left:17px">Month to month</span>
                  </div>
                </div>