    <div class="d-flex flex-row justify-content-between">
        <ul class="links-box p-0 ls list">
        <li>
            <div class="d-flex">
                <div class="flex-shrink-0">
                    <label class="fs-16 text-white fas fa-map fa-fw" id="adress"></label>
                </div>
                    
                      <div class="flex-grow-1 ms-3">
                           <hr class="hr3">
                          <h3>Name of RCFE</h3>
                           Pebble Brook Assisted Living<br>
                            RCFE License # 336425448<br>
                            <br>
                            <b>Facility Address</b> <br>
                            <a target="_blank" style="color:#993366; text-decoration: underline;" class="text-decoration-none text-dark" href="https://www.google.com/maps/dir//Pebble+Brook+Senior+Assisted+Living,+33722+Pebble+Brook+Cir,+Temecula,+CA+92592/@33.4867902,-117.1411927,12z/data=!4m9!4m8!1m0!1m5!1m1!1s0x80db78a9c85a16cf:0xab889f9d2ade632!2m2!1d-117.0711526!2d33.4868099!3e0" rel="nofollow">33722 Pebble Brook Cir,<br> Temecula, CA 92592</a>                                            </div>
            </div>
        </li>
                <li>
                       <label class="fs-16 text-white me-2 fas fa-phone-volume fa-fw" id="phone"></label>
                        <br>
                        <b>Call Us to Schedule a Tour</b><br> 
                        <a class="text-decoration-none  ms-3 text-dark"   style="color:#993366; text-decoration: underline;" href="tel:951-303-0253">951-303-0253</a> 
                       <br> <br> <b>Send Email</b><br> <a class="text-decoration-none  ms-3 text-dark"   style="color:#993366; text-decoration: underline;" href="mailto:pbshomecare@gmail.com">pbshomecare@gmail.com</a>
                        <hr class="hr3">
                         
                                          
                </li>
        </ul>
   </div>